"""
cashproof_ai/parsers/pdf_parser.py

Fresh PDF bank-statement parser for CashProof AI.
Uses pdfplumber (preferred) with pdfminer fallback.

Returns: (account_meta dict, [transaction dict, ...])

account_meta keys:
  client_name, bank_name, account_number, last4, account_title,
  account_type, currency, period_start, period_end,
  beginning_balance, ending_balance,
  statement_total_credits, statement_total_debits

transaction dict keys:
  transaction_date, value_date, description, reference_number,
  check_number, debit_amount, credit_amount, net_amount,
  transaction_type, counterparty_info, source_page, balance
"""

import re
import logging
from datetime import datetime, date
from decimal import Decimal, InvalidOperation

logger = logging.getLogger(__name__)

# ── Regex helpers ─────────────────────────────────────────────────────────────

DATE_PATTERNS = [
    re.compile(r'\b(\d{1,2}[/\-]\d{1,2}[/\-]\d{2,4})\b'),
    re.compile(r'\b(\d{4}[/\-]\d{1,2}[/\-]\d{1,2})\b'),
    re.compile(r'\b(\w{3,9}\s+\d{1,2},?\s+\d{4})\b'),  # Jan 15, 2024
    re.compile(r'\b(\d{1,2}\s+\w{3,9}\s+\d{4})\b'),     # 15 Jan 2024
]

AMOUNT_PATTERN = re.compile(
    r'[\$\£\€]?\s*([\d,]+(?:\.\d{1,2})?)(?:\s*\(([\d,]+(?:\.\d{1,2})?)\))?'
)

BALANCE_KEYWORDS = re.compile(
    r'beginning\s+balance|opening\s+balance|previous\s+balance|'
    r'starting\s+balance|balance\s+forward',
    re.IGNORECASE
)
ENDING_BALANCE_KEYWORDS = re.compile(
    r'ending\s+balance|closing\s+balance|current\s+balance',
    re.IGNORECASE
)
PERIOD_PATTERNS = [
    re.compile(
        r'(?:statement\s+period|period)[:\s]+(\w{3,9}\s+\d{1,2},?\s+\d{4})\s*'
        r'(?:to|through|thru|-)\s*(\w{3,9}\s+\d{1,2},?\s+\d{4})',
        re.IGNORECASE
    ),
    re.compile(
        r'(\d{1,2}[/\-]\d{1,2}[/\-]\d{2,4})\s*(?:to|through|thru|-)\s*'
        r'(\d{1,2}[/\-]\d{1,2}[/\-]\d{2,4})',
        re.IGNORECASE
    ),
]

BANK_INDICATORS = {
    'chase': 'JPMorgan Chase Bank',
    'jpmorgan': 'JPMorgan Chase Bank',
    'bank of america': 'Bank of America',
    'wells fargo': 'Wells Fargo Bank',
    'citibank': 'Citibank',
    'citi bank': 'Citibank',
    'td bank': 'TD Bank',
    'us bank': 'US Bank',
    'usbank': 'US Bank',
    'pnc': 'PNC Bank',
    'regions': 'Regions Bank',
    'suntrust': 'SunTrust Bank',
    'truist': 'Truist Bank',
    'capital one': 'Capital One',
    'fifth third': 'Fifth Third Bank',
    'navy federal': 'Navy Federal Credit Union',
    'bb&t': 'BB&T Bank',
    'qnb': 'QNB Bank',
    'keybank': 'KeyBank',
    'huntington': 'Huntington Bank',
    'citizens': 'Citizens Bank',
    'ally': 'Ally Bank',
    'discover': 'Discover Bank',
    'signature': 'Signature Bank',
    'sterling': 'Sterling Bank',
}

TRANSFER_KEYWORDS = re.compile(
    r'\b(?:transfer|internal\s+transfer|online\s+transfer|wire\s+transfer|'
    r'int\s+txfr|int\.?\s*txfr|book\s+transfer)\b',
    re.IGNORECASE
)
ACH_KEYWORDS      = re.compile(r'\bACH\b', re.IGNORECASE)
CHECK_KEYWORDS    = re.compile(r'\b(?:check|cheque|chk)\b|\bCHECK\s*#?\d+\b', re.IGNORECASE)
FEE_KEYWORDS      = re.compile(r'\b(?:fee|charge|service\s+charge|maintenance|overdraft)\b', re.IGNORECASE)
INTEREST_KEYWORDS = re.compile(r'\b(?:interest|interest\s+income|int\.?\s*pd)\b', re.IGNORECASE)
CARD_KEYWORDS     = re.compile(r'\b(?:card|merchant|settlement|deposit\s+settlement)\b', re.IGNORECASE)

ACCOUNT_NUMBER_RE = re.compile(r'(?:account\s+(?:number|#|no\.?):?\s*)([X\*\d]{4,20})', re.IGNORECASE)
LAST4_RE          = re.compile(r'(?:ending|last\s+4|x+)(\d{4})', re.IGNORECASE)


# ── Parse helpers ─────────────────────────────────────────────────────────────

def _parse_amount(text: str) -> Decimal | None:
    """Convert a string like '1,234.56' or '(1,234.56)' to Decimal."""
    if not text:
        return None
    text = text.strip()
    negative = text.startswith('(') and text.endswith(')')
    text = text.strip('()').replace(',', '').replace('$', '').replace('£', '').replace('€', '').strip()
    try:
        val = Decimal(text)
        return -val if negative else val
    except InvalidOperation:
        return None


def _parse_date(text: str) -> date | None:
    """Try multiple date formats, return a date object or None."""
    formats = [
        '%m/%d/%Y', '%m/%d/%y', '%m-%d-%Y', '%m-%d-%y',
        '%Y-%m-%d', '%Y/%m/%d',
        '%B %d, %Y', '%B %d %Y', '%b %d, %Y', '%b %d %Y',
        '%d %B %Y', '%d %b %Y',
    ]
    text = text.strip().rstrip(',')
    for fmt in formats:
        try:
            return datetime.strptime(text, fmt).date()
        except ValueError:
            continue
    return None


def _extract_date_from_line(line: str) -> date | None:
    for pat in DATE_PATTERNS:
        m = pat.search(line)
        if m:
            d = _parse_date(m.group(1))
            if d:
                return d
    return None


def _extract_amounts_from_line(line: str) -> list[Decimal]:
    """Return all numeric amounts found in a line."""
    amounts = []
    # Match patterns like: 1,234.56  or  (1,234.56)
    for m in re.finditer(r'\(?([\d,]+\.\d{2})\)?', line):
        val = _parse_amount(m.group(0))
        if val is not None:
            amounts.append(val)
    return amounts


def _classify_transaction_type(description: str, is_debit: bool) -> str:
    """Return one of the §4 type codes."""
    desc = description or ''
    if FEE_KEYWORDS.search(desc):
        return 'E'
    if INTEREST_KEYWORDS.search(desc):
        return 'D'
    if CHECK_KEYWORDS.search(desc):
        return 'F'
    if TRANSFER_KEYWORDS.search(desc):
        return 'C'  # candidate; interbank service will confirm/deny
    if ACH_KEYWORDS.search(desc):
        return 'G'
    if CARD_KEYWORDS.search(desc):
        return 'H'
    return 'B' if is_debit else 'A'


def _detect_bank_name(text: str) -> str:
    text_lower = text.lower()
    for key, name in BANK_INDICATORS.items():
        if key in text_lower:
            return name
    return ''


# ── Main Parser Class ─────────────────────────────────────────────────────────

class PDFStatementParser:
    """
    Fresh PDF parser for CashProof AI.
    Supports most common US bank statement layouts.
    """

    def __init__(self, file_path: str):
        self.file_path = file_path
        self._pages_text: list[str] = []

    # ── Public ────────────────────────────────────────────────────────────────

    def parse(self) -> tuple[dict, list[dict]]:
        """
        Parse the PDF and return (account_meta, transactions).
        """
        self._pages_text = self._extract_text()
        full_text = '\n'.join(self._pages_text)

        account_meta  = self._extract_header(full_text)
        transactions  = self._extract_transactions(full_text)

        # Compute computed totals for validation
        total_credits = sum(t['credit_amount'] for t in transactions if t['credit_amount'])
        total_debits  = sum(t['debit_amount']  for t in transactions if t['debit_amount'])
        if account_meta.get('statement_total_credits') is None:
            account_meta['statement_total_credits'] = total_credits
        if account_meta.get('statement_total_debits') is None:
            account_meta['statement_total_debits'] = total_debits

        return account_meta, transactions

    # ── Text extraction ───────────────────────────────────────────────────────

    def _extract_text(self) -> list[str]:
        """Extract text page-by-page. Try pdfplumber first, fall back to pdfminer."""
        try:
            import pdfplumber
            pages = []
            with pdfplumber.open(self.file_path) as pdf:
                for page in pdf.pages:
                    text = page.extract_text() or ''
                    pages.append(text)
            return pages
        except Exception as e:
            logger.warning(f"pdfplumber failed ({e}), falling back to pdfminer")

        try:
            from pdfminer.high_level import extract_pages
            from pdfminer.layout import LTTextContainer
            pages = []
            for page_layout in extract_pages(self.file_path):
                page_text = []
                for element in page_layout:
                    if isinstance(element, LTTextContainer):
                        page_text.append(element.get_text())
                pages.append('\n'.join(page_text))
            return pages
        except Exception as e:
            logger.error(f"pdfminer also failed: {e}")
            return []

    # ── Header extraction ─────────────────────────────────────────────────────

    def _extract_header(self, text: str) -> dict:
        meta = {
            'client_name': '',
            'bank_name': '',
            'account_number': '',
            'last4': '',
            'account_title': 'Operating Account',
            'account_type': 'checking',
            'currency': 'USD',
            'period_start': None,
            'period_end': None,
            'beginning_balance': None,
            'ending_balance': None,
            'statement_total_credits': None,
            'statement_total_debits': None,
        }

        # Bank name
        meta['bank_name'] = _detect_bank_name(text[:500])

        # Account number
        m = ACCOUNT_NUMBER_RE.search(text[:2000])
        if m:
            raw = m.group(1)
            meta['account_number'] = raw
            meta['last4'] = raw[-4:] if len(raw) >= 4 else raw
        else:
            m4 = LAST4_RE.search(text[:2000])
            if m4:
                meta['last4'] = m4.group(1)
                meta['account_number'] = f'xxxx{m4.group(1)}'

        # Statement period
        for pat in PERIOD_PATTERNS:
            m = pat.search(text[:3000])
            if m:
                d1 = _parse_date(m.group(1))
                d2 = _parse_date(m.group(2))
                if d1 and d2:
                    meta['period_start'] = d1
                    meta['period_end']   = d2
                    break

        # Balances
        for line in text.splitlines():
            if BALANCE_KEYWORDS.search(line):
                amounts = _extract_amounts_from_line(line)
                if amounts and meta['beginning_balance'] is None:
                    meta['beginning_balance'] = amounts[-1]
            if ENDING_BALANCE_KEYWORDS.search(line):
                amounts = _extract_amounts_from_line(line)
                if amounts:
                    meta['ending_balance'] = amounts[-1]

        # Statement totals (look for "Total Credits/Debits" summary lines)
        total_credit_re = re.compile(r'total\s+(?:credits?|deposits?)[:\s]+([\d,]+\.\d{2})', re.IGNORECASE)
        total_debit_re  = re.compile(r'total\s+(?:debits?|withdrawals?|payments?)[:\s]+([\d,]+\.\d{2})', re.IGNORECASE)
        m = total_credit_re.search(text)
        if m:
            meta['statement_total_credits'] = _parse_amount(m.group(1))
        m = total_debit_re.search(text)
        if m:
            meta['statement_total_debits'] = _parse_amount(m.group(1))

        # Client/account holder name — usually near top after bank name
        header_lines = [l.strip() for l in text[:1500].splitlines() if l.strip()]
        for i, line in enumerate(header_lines[:20]):
            # Lines that look like a person/company name (title-case, no digits, ≥3 words or ≥2 long words)
            if (re.match(r'^[A-Z][A-Za-z\s\.\,&\-]+$', line)
                    and len(line) > 5
                    and not any(kw in line.lower() for kw in ['bank', 'statement', 'account', 'page'])):
                meta['client_name'] = line
                break

        # Account type guess from keywords
        text_lower = text[:3000].lower()
        if 'savings' in text_lower:
            meta['account_type'] = 'savings'
        elif 'money market' in text_lower:
            meta['account_type'] = 'money_market'
        elif 'payroll' in text_lower:
            meta['account_type'] = 'payroll'
        elif 'escrow' in text_lower:
            meta['account_type'] = 'escrow'

        return meta

    # ── Transaction extraction ────────────────────────────────────────────────

    def _extract_transactions(self, full_text: str) -> list[dict]:
        """
        Extract transactions. Works by finding date-anchored lines then
        associating amounts with debit/credit columns based on position
        or on column header keywords.
        """
        transactions = []

        # Determine column layout by scanning for header row
        col_layout = self._detect_column_layout(full_text)

        if col_layout == 'three_col':
            transactions = self._parse_three_column(full_text)
        else:
            transactions = self._parse_two_column(full_text)

        return transactions

    def _detect_column_layout(self, text: str) -> str:
        """
        Determine if statement has 3-column (Date / Description / Debit / Credit / Balance)
        or 2-column (Date / Description / Amount) layout.
        """
        header_re = re.compile(
            r'(?:debit|withdrawal|payment).*?(?:credit|deposit)',
            re.IGNORECASE | re.DOTALL
        )
        if header_re.search(text[:3000]):
            return 'three_col'
        return 'two_col'

    def _parse_three_column(self, text: str) -> list[dict]:
        """
        Parse statements that have separate Debit / Credit columns.
        Strategy: scan lines for date-anchored rows; extract rightmost 2–3
        numbers as (debit_or_credit, balance) based on column position heuristics.
        """
        results = []
        lines = text.splitlines()
        i = 0
        page_number = 1

        while i < len(lines):
            line = lines[i]

            # Detect page boundary
            if re.search(r'page\s+\d+', line, re.IGNORECASE):
                m = re.search(r'page\s+(\d+)', line, re.IGNORECASE)
                if m:
                    page_number = int(m.group(1))

            tx_date = _extract_date_from_line(line)
            if not tx_date:
                i += 1
                continue

            # Gather continuation lines (no date at start, not blank, not header)
            desc_lines = [line]
            j = i + 1
            while j < len(lines) and j < i + 4:
                next_line = lines[j]
                if not next_line.strip():
                    break
                if _extract_date_from_line(next_line):
                    break
                if re.match(r'\s*(date|description|debit|credit|balance|amount)\s*$',
                             next_line, re.IGNORECASE):
                    break
                desc_lines.append(next_line)
                j += 1

            combined = ' '.join(desc_lines)
            amounts = _extract_amounts_from_line(combined)

            if len(amounts) < 1:
                i = j
                continue

            # Heuristic: last amount is balance, second-last is the transaction amount.
            # If only 1 amount, treat it as net (no running balance).
            if len(amounts) >= 2:
                balance = amounts[-1]
                tx_amt  = amounts[-2]
            else:
                balance = None
                tx_amt  = amounts[0]

            # Determine debit vs credit
            # If "(amount)" pattern present it's a debit on some statements
            raw_combined = combined
            is_debit = bool(re.search(r'\(' + re.escape(str(abs(tx_amt)).replace(',','')) + r'\)',
                                       raw_combined))

            # Fallback: keyword in line
            if not is_debit:
                debit_col_re  = re.compile(r'(?<=\s)([\d,]+\.\d{2})\s+(?=(?:[\d,]+\.\d{2})\s*$)', re.IGNORECASE)
                # If there are 3 numbers and first non-balance is in "debit" column position — heuristic
                if len(amounts) >= 3:
                    # first extra amount = debit, second = credit, last = balance
                    # whichever is non-zero is the transaction
                    if amounts[-3] != Decimal('0'):
                        tx_amt  = amounts[-3]
                        is_debit = True
                    elif amounts[-2] != Decimal('0'):
                        tx_amt  = amounts[-2]
                        is_debit = False

            # Description = everything between date and amounts
            desc = self._clean_description(combined, tx_date)

            debit_amount  = abs(tx_amt) if is_debit  else None
            credit_amount = abs(tx_amt) if not is_debit else None
            net_amount    = -abs(tx_amt) if is_debit else abs(tx_amt)

            results.append(self._build_tx(
                transaction_date=tx_date,
                description=desc,
                debit_amount=debit_amount,
                credit_amount=credit_amount,
                net_amount=net_amount,
                balance=balance,
                source_page=str(page_number),
                combined_line=combined,
            ))
            i = j

        return results

    def _parse_two_column(self, text: str) -> list[dict]:
        """
        Parse statements where each row has a single signed Amount column.
        Positive = credit, negative = debit.
        """
        results = []
        lines = text.splitlines()
        i = 0
        page_number = 1

        while i < len(lines):
            line = lines[i]

            if re.search(r'page\s+\d+', line, re.IGNORECASE):
                m = re.search(r'page\s+(\d+)', line, re.IGNORECASE)
                if m:
                    page_number = int(m.group(1))

            tx_date = _extract_date_from_line(line)
            if not tx_date:
                i += 1
                continue

            desc_lines = [line]
            j = i + 1
            while j < len(lines) and j < i + 4:
                next_line = lines[j]
                if not next_line.strip():
                    break
                if _extract_date_from_line(next_line):
                    break
                desc_lines.append(next_line)
                j += 1

            combined = ' '.join(desc_lines)
            amounts = _extract_amounts_from_line(combined)

            if not amounts:
                i = j
                continue

            balance   = amounts[-1] if len(amounts) >= 2 else None
            net_amount = amounts[-2] if len(amounts) >= 2 else amounts[0]

            # Negative / parenthetical → debit
            is_debit = net_amount < 0 or bool(
                re.search(r'\(' + re.escape(str(abs(net_amount)).replace(',','')) + r'\)', combined)
            )

            debit_amount  = abs(net_amount) if is_debit  else None
            credit_amount = abs(net_amount) if not is_debit else None
            final_net     = -abs(net_amount) if is_debit else abs(net_amount)

            desc = self._clean_description(combined, tx_date)

            results.append(self._build_tx(
                transaction_date=tx_date,
                description=desc,
                debit_amount=debit_amount,
                credit_amount=credit_amount,
                net_amount=final_net,
                balance=balance,
                source_page=str(page_number),
                combined_line=combined,
            ))
            i = j

        return results

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _clean_description(self, combined: str, tx_date: date) -> str:
        """Strip date string and trailing amounts from description."""
        text = combined
        # Remove dates
        for pat in DATE_PATTERNS:
            text = pat.sub('', text)
        # Remove amounts (numbers with dots/commas and optional parens)
        text = re.sub(r'\([\d,]+\.\d{2}\)', '', text)
        text = re.sub(r'[\d,]+\.\d{2}', '', text)
        # Remove currency symbols
        text = re.sub(r'[\$\£\€]', '', text)
        # Collapse whitespace
        text = re.sub(r'\s+', ' ', text).strip()
        return text[:500] if text else 'Transaction'

    def _build_tx(self, *, transaction_date, description, debit_amount,
                  credit_amount, net_amount, balance, source_page, combined_line) -> dict:
        is_debit = debit_amount is not None
        tx_type  = _classify_transaction_type(description, is_debit)

        # Reference / check numbers
        ref_m = re.search(r'(?:ref|reference|trace)[#:\s]+([A-Z0-9]{6,})', description, re.IGNORECASE)
        chk_m = re.search(r'(?:check|chk)\s*#?\s*(\d{4,})', description, re.IGNORECASE)

        return {
            'transaction_date': transaction_date,
            'value_date': None,
            'description': description,
            'reference_number': ref_m.group(1) if ref_m else '',
            'check_number': chk_m.group(1) if chk_m else '',
            'debit_amount': debit_amount,
            'credit_amount': credit_amount,
            'net_amount': net_amount,
            'transaction_type': tx_type,
            'counterparty_info': '',
            'source_page': source_page,
            'balance': balance,
        }
